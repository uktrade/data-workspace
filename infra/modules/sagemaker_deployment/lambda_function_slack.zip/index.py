import urllib3
import json
import os

http = urllib3.PoolManager()
webhook_id = os.environ["SLACK_WEBHOOK"]

def lambda_handler(event, context):
    try:
        webhook_url = f"https://hooks.slack.com/services/{webhook_id}"
   
        for record in event['Records']:
            sns_message = json.loads(record['Sns']['Message'])
            alert_name = sns_message.get('AlarmName', 'Unknown Alert')
            state = sns_message.get('NewStateValue', 'Unknown State')
            reason = sns_message.get('NewStateReason', 'No reason provided')

            payload = {
                "text": f"*Alert:* {alert_name}\n*State:* {state}\n*Reason:* {reason}"
            }

            encoded_data = json.dumps(payload).encode('utf-8')
            response = http.request(
                "POST",
                webhook_url,
                body=encoded_data,
                headers={"Content-Type": "application/json"}
            )

            if response.status != 200:
                print(f"Failed to send alert: {response.data.decode('utf-8')}")

        return {"statusCode": 200}
    except ValueError as ve:
        print(f"Validation error: {str(ve)}")
        return {
            "statusCode": 400,
            "body": json.dumps(f"Validation Error: {str(ve)}")
        }
    except Exception as e:
        print(f"Error processing SNS: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps(f"Error: {str(e)}")
        }